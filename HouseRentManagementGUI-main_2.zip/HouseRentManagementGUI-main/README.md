# HouseRentManagementGUI
This is a project of house rent management system for a owner and the project has no database server.

Required username: admin

Required password: admin

The data on the project will not save because the project does not support any database server.

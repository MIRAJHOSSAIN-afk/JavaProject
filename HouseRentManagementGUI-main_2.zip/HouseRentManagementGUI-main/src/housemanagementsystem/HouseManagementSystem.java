
package housemanagementsystem;


public class HouseManagementSystem extends login {

    
    public static void main(String[] args) {
        
    }
    
}

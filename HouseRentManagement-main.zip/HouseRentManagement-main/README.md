# HouseRentManagement
This is a JAVA Swing GUI project about House Rent Management and this is for an house owner.

Required Username : admin

Required Password : admin

The data of the project will be not be saved as any Database is not initiated.
